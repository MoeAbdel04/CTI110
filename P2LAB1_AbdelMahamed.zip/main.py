miles_per_gallon = float(input("Enter the car's gas mileage (miles per gallon): "))
cost_per_gallon = float(input("Enter the cost of gas (dollars per gallon): "))

distances = [20, 75, 500]

results = []

for distance in distances:
    cost = (distance / miles_per_gallon) * cost_per_gallon
    results.append((distance, cost))

print("Gas Costs:")
print("-----------")
for distance, cost in results:
    print(f"For {distance} miles: ${cost:.2f}")
